#include <stdio.h>

int main() 
{
	int value;
	scanf("%d", &value);
	printf("Antecessor: %d", value - 1);
	return 0;
}
