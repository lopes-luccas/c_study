#include <stdio.h>

int main()
{
	double base, altura, area;
	scanf("%lf", &base);
	scanf("%lf", &altura);
	area = base * altura;
	printf("Area: %.2lf", area);
	return 0;
	
}
